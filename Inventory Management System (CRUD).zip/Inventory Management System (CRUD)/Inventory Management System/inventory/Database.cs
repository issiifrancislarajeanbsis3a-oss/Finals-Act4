using System;
using System.Data.OleDb;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace inventory
{
    public static class Database
    {
        // sampledb.accdb sits in the project folder (two levels above bin\Debug), same as in the video
        public static readonly string DBpATH = Path.GetFullPath(
            Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\sampledb.accdb"));

        private static readonly string connectionString =
            @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + DBpATH + ";Persist Security Info=False;";

        public static OleDbConnection GetConnection()
        {
            return new OleDbConnection(connectionString);
        }

        // Makes sure the tables the Dashboard needs exist. Safe to call many times:
        // it only creates a table when it is missing and never touches existing data.
        public static void EnsureTables()
        {
            using (OleDbConnection con = GetConnection())
            {
                con.Open();

                if (!TableExists(con, "Products"))
                {
                    Run(con,
                        "CREATE TABLE Products (" +
                        "ProductID AUTOINCREMENT PRIMARY KEY, " +
                        "ProductName TEXT(100) NOT NULL, " +
                        "Category TEXT(100), " +
                        "[Description] TEXT(255), " +
                        "UnitPrice CURRENCY, " +
                        "Quantity LONG, " +
                        "ReorderLevel LONG, " +
                        "CreatedAt DATETIME)");
                }

                if (!TableExists(con, "ActivityLogs"))
                {
                    Run(con,
                        "CREATE TABLE ActivityLogs (" +
                        "LogID AUTOINCREMENT PRIMARY KEY, " +
                        "UserID LONG, " +
                        "ActionText TEXT(255), " +
                        "LogDate DATETIME)");
                }

                SeedBeautyProducts(con);
            }
        }

        // Adds a few sample beauty products ONCE, when the Products table is empty.
        // After that it never adds them again, even if you delete everything.
        private static void SeedBeautyProducts(OleDbConnection con)
        {
            using (OleDbCommand check = new OleDbCommand("SELECT COUNT(*) FROM Products", con))
            {
                if (Convert.ToInt32(check.ExecuteScalar()) > 0) return;
            }
            using (OleDbCommand done = new OleDbCommand(
                "SELECT COUNT(*) FROM ActivityLogs WHERE ActionText = 'Sample products added'", con))
            {
                if (Convert.ToInt32(done.ExecuteScalar()) > 0) return;
            }

            object[][] items =
            {
                new object[] { "Rose Glow Lip Tint",      "Makeup",       "Sheer rose tint with a dewy finish",        189m, 45, 10 },
                new object[] { "Hydrating Face Serum",    "Skincare",     "Hyaluronic acid serum, 30 ml",              450m,  8, 10 },
                new object[] { "Velvet Matte Lipstick",   "Makeup",       "Long-wear matte lipstick in berry pink",    249m,  0, 10 },
                new object[] { "Vitamin C Moisturizer",   "Skincare",     "Brightening day cream for glowing skin",    320m, 30,  8 },
                new object[] { "Cherry Blossom Body Mist","Fragrance",    "Light floral body mist, 100 ml",            275m, 22, 10 },
                new object[] { "Argan Hair Oil",          "Haircare",     "Smoothing oil for frizz control",           210m,  5,  8 },
                new object[] { "Pastel Nail Polish Set",  "Nails",        "6-piece pastel gel-finish polish set",      165m, 40, 10 },
                new object[] { "Blush Brush Set",         "Beauty Tools", "Soft 5-piece makeup brush set",             380m, 18,  5 }
            };

            foreach (object[] it in items)
            {
                using (OleDbCommand ins = new OleDbCommand(
                    "INSERT INTO Products (ProductName, Category, [Description], UnitPrice, Quantity, ReorderLevel, CreatedAt) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)", con))
                {
                    ins.Parameters.Add("?", OleDbType.VarWChar).Value = (string)it[0];
                    ins.Parameters.Add("?", OleDbType.VarWChar).Value = (string)it[1];
                    ins.Parameters.Add("?", OleDbType.VarWChar).Value = (string)it[2];
                    ins.Parameters.Add("?", OleDbType.Currency).Value = (decimal)it[3];
                    ins.Parameters.Add("?", OleDbType.Integer).Value = (int)it[4];
                    ins.Parameters.Add("?", OleDbType.Integer).Value = (int)it[5];
                    ins.Parameters.Add("?", OleDbType.Date).Value = DateTime.Now;
                    ins.ExecuteNonQuery();
                }
            }

            using (OleDbCommand log = new OleDbCommand(
                "INSERT INTO ActivityLogs (UserID, ActionText, LogDate) VALUES (?, ?, ?)", con))
            {
                log.Parameters.Add("?", OleDbType.Integer).Value = 0;
                log.Parameters.Add("?", OleDbType.VarWChar).Value = "Sample products added";
                log.Parameters.Add("?", OleDbType.Date).Value = DateTime.Now;
                log.ExecuteNonQuery();
            }
        }

        private static bool TableExists(OleDbConnection con, string tableName)
        {
            return con.GetSchema("Tables", new string[] { null, null, tableName, "TABLE" }).Rows.Count > 0;
        }

        private static void Run(OleDbConnection con, string sql)
        {
            using (OleDbCommand cmd = new OleDbCommand(sql, con))
                cmd.ExecuteNonQuery();
        }

        // ---- kept from your original project so Sign In / Register / Dashboard keep working ----

        public static string HashPassword(string password)
        {
            using (SHA256 sha = SHA256.Create())
            {
                byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder sb = new StringBuilder();
                foreach (byte b in bytes) sb.Append(b.ToString("x2"));
                return sb.ToString();
            }
        }

        public static void LogActivity(int userId, string action)
        {
            try
            {
                using (OleDbConnection con = GetConnection())
                using (OleDbCommand cmd = new OleDbCommand(
                    "INSERT INTO ActivityLogs (UserID, ActionText, LogDate) VALUES (?, ?, ?)", con))
                {
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = userId;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = action;
                    cmd.Parameters.Add("?", OleDbType.Date).Value = DateTime.Now;
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
            catch { /* logging should never crash the app */ }
        }
    }
}
