using System;
using System.Data;
using System.Data.OleDb;
using System.Globalization;
using System.Windows.Forms;

namespace inventory
{
    public partial class DashboardForm : Form
    {
        private readonly int currentUserId;
        private readonly Form signInForm;
        private bool loggedOut = false;
        private int selectedProductId = -1;   

        public DashboardForm()
        {
            InitializeComponent();
        }

        public DashboardForm(int userId, string fullName, string role, Form signIn)
        {
            InitializeComponent();
            currentUserId = userId;
            signInForm = signIn;
        }

      
        private void DashboardForm_Load(object sender, EventArgs e)
        {
            if (DesignMode) return;

            cboCategory.Items.AddRange(new object[]
            {
                "Skincare",
                "Makeup",
                "Haircare",
                "Fragrance",
                "Nails",
                "Body Care",
                "Beauty Tools",
                "Accessories"
            });

            try
            {
                Database.EnsureTables();   
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error: " + ex.Message, "Dashboard",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LoadProducts();
        }


        private void LoadProducts()
        {
            try
            {
                string sql = "SELECT ProductID, ProductName, Category, [Description], UnitPrice, Quantity, ReorderLevel, CreatedAt FROM Products";
                string search = txtSearch.Text.Trim();
                if (search != "")
                    sql += " WHERE ProductName LIKE ? OR Category LIKE ? OR [Description] LIKE ?";
                sql += " ORDER BY ProductID DESC";

                using (OleDbConnection con = Database.GetConnection())
                using (OleDbCommand cmd = new OleDbCommand(sql, con))
                {
                    if (search != "")
                    {
                        string like = "%" + search + "%";
                        cmd.Parameters.Add("?", OleDbType.VarWChar).Value = like;
                        cmd.Parameters.Add("?", OleDbType.VarWChar).Value = like;
                        cmd.Parameters.Add("?", OleDbType.VarWChar).Value = like;
                    }

                    DataTable table = new DataTable();
                    new OleDbDataAdapter(cmd).Fill(table);
                    dgvProducts.DataSource = table;

                    dgvProducts.Columns["ProductID"].FillWeight = 55;
                    dgvProducts.Columns["ProductName"].FillWeight = 110;
                    dgvProducts.Columns["Category"].FillWeight = 110;
                    dgvProducts.Columns["Description"].FillWeight = 130;
                    dgvProducts.Columns["UnitPrice"].FillWeight = 75;
                    dgvProducts.Columns["Quantity"].FillWeight = 70;
                    dgvProducts.Columns["ReorderLevel"].FillWeight = 85;
                    dgvProducts.Columns["CreatedAt"].FillWeight = 120;
                    dgvProducts.Columns["UnitPrice"].DefaultCellStyle.Format = "N2";
                    dgvProducts.Columns["CreatedAt"].DefaultCellStyle.Format = "g";
                    dgvProducts.ClearSelection();
                }

                UpdateStats();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading products: " + ex.Message, "Dashboard",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
        private void UpdateStats()
        {
            int total = 0, inStock = 0, low = 0, outOfStock = 0;

            using (OleDbConnection con = Database.GetConnection())
            using (OleDbCommand cmd = new OleDbCommand("SELECT Quantity, ReorderLevel FROM Products", con))
            {
                con.Open();
                using (OleDbDataReader r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        int qty = ToInt(r["Quantity"]);
                        int reorder = ToInt(r["ReorderLevel"]);
                        total++;
                        if (qty <= 0) outOfStock++;
                        else if (qty <= reorder) low++;
                        else inStock++;
                    }
                }
            }

            lblTotalValue.Text = total.ToString();
            lblInStockValue.Text = inStock.ToString();
            lblLowValue.Text = low.ToString();
            lblOutValue.Text = outOfStock.ToString();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            LoadProducts();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text != "") txtSearch.Clear();   
            else LoadProducts();
        }

        
        private void btnAdd_Click(object sender, EventArgs e)
        {
            string name, category, description;
            decimal price;
            int qty, reorder;
            if (!ReadInput(out name, out category, out description, out price, out qty, out reorder)) return;

            try
            {
                using (OleDbConnection con = Database.GetConnection())
                using (OleDbCommand cmd = new OleDbCommand(
                    "INSERT INTO Products (ProductName, Category, [Description], UnitPrice, Quantity, ReorderLevel, CreatedAt) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)", con))
                {
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = name;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = category;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = description;
                    cmd.Parameters.Add("?", OleDbType.Currency).Value = price;
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = qty;
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = reorder;
                    cmd.Parameters.Add("?", OleDbType.Date).Value = DateTime.Now;
                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                Database.LogActivity(currentUserId, "Added product: " + name);
                ClearFields();
                LoadProducts();
                MessageBox.Show("Product added.", "Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Add Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedProductId < 0)
            {
                MessageBox.Show("Click a product in the table first.", "Update",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            string name, category, description;
            decimal price;
            int qty, reorder;
            if (!ReadInput(out name, out category, out description, out price, out qty, out reorder)) return;

            try
            {
                using (OleDbConnection con = Database.GetConnection())
                using (OleDbCommand cmd = new OleDbCommand(
                    "UPDATE Products SET ProductName = ?, Category = ?, [Description] = ?, UnitPrice = ?, " +
                    "Quantity = ?, ReorderLevel = ? WHERE ProductID = ?", con))
                {
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = name;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = category;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = description;
                    cmd.Parameters.Add("?", OleDbType.Currency).Value = price;
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = qty;
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = reorder;
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = selectedProductId;
                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                Database.LogActivity(currentUserId, "Updated product ID " + selectedProductId);
                ClearFields();
                LoadProducts();
                MessageBox.Show("Product updated.", "Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Update Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // --------------------------------------------------------- DELETE
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedProductId < 0)
            {
                MessageBox.Show("Click a product in the table first.", "Delete",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (MessageBox.Show("Delete \"" + txtProductName.Text.Trim() + "\"?", "Confirm delete",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            try
            {
                using (OleDbConnection con = Database.GetConnection())
                using (OleDbCommand cmd = new OleDbCommand("DELETE FROM Products WHERE ProductID = ?", con))
                {
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = selectedProductId;
                    con.Open();
                    cmd.ExecuteNonQuery();
                }

                Database.LogActivity(currentUserId, "Deleted product ID " + selectedProductId);
                ClearFields();
                LoadProducts();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message, "Delete Product", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearFields();
        }

        
        private void dgvProducts_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;

            DataGridViewRow row = dgvProducts.Rows[e.RowIndex];
            selectedProductId = ToInt(row.Cells["ProductID"].Value);
            txtProductName.Text = Convert.ToString(row.Cells["ProductName"].Value);
            cboCategory.Text = Convert.ToString(row.Cells["Category"].Value);
            txtDescription.Text = Convert.ToString(row.Cells["Description"].Value);
            txtUnitPrice.Text = ToDecimal(row.Cells["UnitPrice"].Value).ToString("0.00", CultureInfo.CurrentCulture);
            txtQuantity.Text = ToInt(row.Cells["Quantity"].Value).ToString();
            txtReorderLevel.Text = ToInt(row.Cells["ReorderLevel"].Value).ToString();
        }

        
        private bool ReadInput(out string name, out string category, out string description,
                               out decimal price, out int qty, out int reorder)
        {
            name = txtProductName.Text.Trim();
            category = cboCategory.Text.Trim();
            description = txtDescription.Text.Trim();
            price = 0;
            qty = 0;
            reorder = 0;

            if (name == "")
            {
                Warn("Please enter the product name.", txtProductName);
                return false;
            }
            if (category == "")
            {
                Warn("Please choose or type a category.", cboCategory);
                return false;
            }
            if (!TryParsePrice(txtUnitPrice.Text, out price) || price < 0)
            {
                Warn("Please enter a valid unit price, for example 150.00", txtUnitPrice);
                return false;
            }
            if (!int.TryParse(txtQuantity.Text.Trim(), NumberStyles.None, CultureInfo.InvariantCulture, out qty))
            {
                Warn("Please enter the quantity as a whole number.", txtQuantity);
                return false;
            }
            if (!int.TryParse(txtReorderLevel.Text.Trim(), NumberStyles.None, CultureInfo.InvariantCulture, out reorder))
            {
                Warn("Please enter the reorder level as a whole number.", txtReorderLevel);
                return false;
            }
            return true;
        }

        private static bool TryParsePrice(string text, out decimal value)
        {
            text = text.Trim();
            return decimal.TryParse(text, NumberStyles.Number, CultureInfo.CurrentCulture, out value)
                || decimal.TryParse(text, NumberStyles.Number, CultureInfo.InvariantCulture, out value);
        }

        private void Warn(string message, Control focus)
        {
            MessageBox.Show(message, "Dashboard", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            focus.Focus();
        }

        private void ClearFields()
        {
            selectedProductId = -1;
            txtProductName.Clear();
            cboCategory.SelectedIndex = -1;
            cboCategory.Text = "";
            txtUnitPrice.Clear();
            txtDescription.Clear();
            txtQuantity.Clear();
            txtReorderLevel.Clear();
            dgvProducts.ClearSelection();
            txtProductName.Focus();
        }

        private static int ToInt(object value)
        {
            if (value == null || value == DBNull.Value) return 0;
            return Convert.ToInt32(value);
        }

        private static decimal ToDecimal(object value)
        {
            if (value == null || value == DBNull.Value) return 0m;
            return Convert.ToDecimal(value);
        }

        
        private void DigitsOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
                e.Handled = true;
        }

        
        private void DecimalOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar) || char.IsDigit(e.KeyChar)) return;
            if (e.KeyChar == '.' && !((TextBox)sender).Text.Contains(".")) return;
            e.Handled = true;
        }

       
        private void btnLogout_Click(object sender, EventArgs e)
        {
            Database.LogActivity(currentUserId, "Signed out");
            loggedOut = true;
            if (signInForm != null) signInForm.Show();
            this.Close();
        }

        private void DashboardForm_FormClosed(object sender, FormClosedEventArgs e)
        {
           
            if (!loggedOut) Application.Exit();
        }
    }
}
