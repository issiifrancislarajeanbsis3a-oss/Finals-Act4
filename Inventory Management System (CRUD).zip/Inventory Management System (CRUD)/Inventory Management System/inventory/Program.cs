using System;
using System.Windows.Forms;

namespace inventory
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                Database.EnsureTables();   // creates the Products table on first run
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database error:\n" + ex.Message + "\n\nDatabase file:\n" + Database.DBpATH +
                    "\n\nMake sure the file exists, Access is closed, and the Microsoft Access Database Engine is installed.",
                    "Inventory Management System", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Application.Run(new SignInForm());
        }
    }
}
