INVENTORY MANAGEMENT SYSTEM - Sign In, Register and Dashboard (pink design)

1. Extract this zip, then double-click inventory.sln (opens in Visual Studio).
2. Install the Microsoft Access Database Engine (ACE OLEDB 12.0) if you have not - 32/64-bit to match your Office.
3. Close Microsoft Access, then press F5 to run.

Sample account: Lara / Lara123

Database:
 - sampledb.accdb is in the project folder (inventory\sampledb.accdb), next to inventory.csproj.
 - The first time the app runs it creates the Products table automatically:
   ProductID, ProductName, Category, Description, UnitPrice, Quantity, ReorderLevel, CreatedAt
 - If the Products table is empty, 8 sample beauty products are added once (skincare, makeup, haircare,
   fragrance, nails, beauty tools) so the cards and table are not blank. Delete or edit them any time.
 - Your Users and ActivityLogs tables are not touched.

Dashboard:
 - Add Product / Update / Delete / Clear / Refresh and live Search all work.
 - Click a row in the table to load it into the form, then press Update or Delete.
 - Cards: Total Products, In Stock (quantity above reorder level),
   Low Stock (quantity at or below reorder level), Out of Stock (quantity 0).
 - Logout returns to the Sign In page.
